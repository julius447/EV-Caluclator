# Developer handover — Ampy EV / Laddbox Calculator

**Audience:** Chris (the developer) + his AI coding agent.
**Goal:** get this calculator live on a WordPress + Bricks page, fed by Ampy's data,
delivering leads, and visually identical to the bundled prototype.

If you want the dense technical contract (every ID, REST route, data field, parser
quirk), read `docs/IMPLEMENTATION-GUIDE.md` next. This document is the practical
walkthrough.

---

## 0. The 60-second mental model

```
   Excel (.xlsx)  ──upload in metabox──►  PHP parses → post meta  ──►  inline JSON
   (cars, boxes,                          _ampy_ev_calc_data            window.AmpyEvCalcData
    rates)                                                                     │
                                                                               ▼
   Bricks page calls  ampy_render_ev_lead_magnet('laddboxkalkylator')   →   HTML markup + JSON
                                                                               │
   engine.js (window.AmpyEvCalculator) reads the JSON, renders into #ampyEvCalc,
   recalculates on every input, and POSTs the lead to the REST API
   (ampy-ev-calc/v1/lead) → n8n webhook or a fallback notification email.
```

Five files, three layers: **data** (Excel → post meta → inline JSON), **logic +
view** (`engine.js`), **style** (`styles.css`), all bootstrapped by **`backend.php`**.
Nothing is fetched at runtime — the data is printed inline into the page, so the
calculator paints instantly.

---

## 1. Prerequisites (check these FIRST)

| Requirement | How to check / fix |
|---|---|
| **`lead-magnet` custom post type exists** | Visit `wp-admin`. If you see a "Lead Magnets" menu (the battery/LED calculators use it), you're done. If **not**, register it — snippet in §2 below. **The metabox and render do nothing without this CPT.** |
| **FluentSnippets plugin** (only for the snippets delivery method) | Installed & active. Not needed if you use the plugin delivery method. |
| **Bricks** (or any way to run a PHP/shortcode in a template) | Bricks "Code" element (PHP) or the `[ampy_ev_lead_magnet]` shortcode in any builder. |
| **Fonts**: Plus Jakarta Sans, Outfit, JetBrains Mono | See §6. On ampy.se these already load (Core Framework). |
| **Rem scale**: root `font-size: 62.5%` (1rem = 10px) | See §6 — the whole stylesheet assumes this. ampy.se already does it. |
| **PHP 8.0+, `ZipArchive` extension** | Required by the .xlsx importer. Standard on managed WP hosts. |

---

## 2. Register the `lead-magnet` CPT (only if it doesn't already exist)

> Skip this if the CPT is already registered (battery/LED calculators ⇒ it is).
> Do **not** register it twice.

Paste into the theme's `functions.php`, a small mu-plugin, or a FluentSnippets PHP
snippet (run location: **Frontend & Backend**):

```php
add_action( 'init', function () {
    register_post_type( 'lead-magnet', array(
        'labels'       => array(
            'name'          => 'Lead Magnets',
            'singular_name' => 'Lead Magnet',
        ),
        'public'       => true,            // needs to be queryable + have a public URL
        'show_ui'      => true,
        'show_in_menu' => true,
        'menu_icon'    => 'dashicons-calculator',
        'supports'     => array( 'title', 'editor', 'custom-fields' ),
        'has_archive'  => false,
        'rewrite'      => array( 'slug' => 'lead-magnet' ),
        'show_in_rest' => true,            // Gutenberg/Bricks friendly
    ) );
} );
```

The render function only serves **published** `lead-magnet` posts.

---

## 3. Install the code — choose ONE method

### Method A — FluentSnippets (matches Ampy's current setup)

Create three snippets from `code/fluentsnippets/`. Set the **Run Location** exactly:

| File | Snippet type | Run location |
|------|--------------|--------------|
| `1-backend.php` | PHP | **Frontend & Backend** (runs everywhere; REST + admin must both work) |
| `2-engine.js`   | JS  | **Frontend** (output in `wp_footer`) |
| `3-styles.css`  | CSS | **Frontend** (output in `wp_head`) |

> `3-styles.css` is the **shared** Ampy calculator stylesheet (battery + LED + EV use
> the same one). If that CSS snippet is *already published* on the site for the other
> calculators, you do **not** need to add it again — it's identical.

### Method B — Plugin (one upload, portable)

1. Zip the folder `code/plugin/ampy-ev-calculator/` (so the zip contains
   `ampy-ev-calculator/ampy-ev-calculator.php`).
2. WP Admin → **Plugins → Add New → Upload Plugin** → choose the zip → Install →
   **Activate**.

That's it — it registers the REST routes/metabox and enqueues the engine + styles.

---

## 4. Create the calculator post and load the data

1. **Lead Magnets → Add New.** Title it e.g. "Laddbox-kalkylator". Note its **slug**
   (e.g. `laddboxkalkylator`) — you'll reference it when placing the calculator.
2. In the **"EV Charging Calculator — Settings"** metabox:
   - **Data Source — Excel File:** click *Choose Excel file from Media Library*,
     upload `data/laddbox-kalkylator-data.xlsx`, select it, **Update/Publish** the
     post. On save the importer parses it and shows a green
     **`OK — 8 EV models, 16 chargers imported.`** badge.
     - If you see a red error (or `0 imported`), the file was regenerated with the
       wrong tool — see `docs/DATA-SCHEMA.md` §"Do NOT regenerate with openpyxl".
   - **Defaults:** optionally pick the default EV and default charger (else the
     first active of each is used).
   - **Lead Delivery:** see §5.
   - **Bilder:** see §7.
3. **Publish** the post.

> The importer only re-runs when the **attachment changes**. To re-import after
> editing the spreadsheet, upload the new file and pick it again (replacing the old).

---

## 5. Wire up lead delivery

In the metabox, **Lead Delivery** section:

- **n8n Webhook URL** (priority): the full lead payload is POSTed here as JSON. Use
  this for the production funnel. Payload shape is documented in
  `docs/IMPLEMENTATION-GUIDE.md` §"Lead payload".
- **Fallback notification email**: used only if the webhook URL is empty. Sends a
  formatted summary via `wp_mail`.

Every lead is also stored (last 100) in post meta and shown in a **Recent Leads**
table in the metabox, regardless of delivery method.

There are two lead actions in the UI, both hitting `POST ampy-ev-calc/v1/lead/{id}`:
`quote_request` (the full form) — that's the real lead.

---

## 6. Fonts and the rem scale (do not skip — this is the #1 cause of "it looks wrong")

**Rem scale.** The entire stylesheet is written assuming **`1rem = 10px`** (i.e.
`html { font-size: 62.5%; }`). If the site root font-size is the browser default
(16px), every dimension renders ~1.6× too large.

- **ampy.se already sets `62.5%`** (Core Framework) — nothing to do there.
- **On any other site / template**, add this once (Bricks → site or page custom CSS):
  ```css
  html { font-size: 62.5%; }
  body { font-size: 1.6rem; }   /* restore a normal 16px base for the rest of the page */
  ```
  (The popover/tooltip uses px fallbacks, so it survives even a 16px root — but the
  rest of the calculator needs the 62.5% scale.)

**Fonts.** The calculator uses three families:

| Family | Used for | Loaded by |
|---|---|---|
| **Plus Jakarta Sans** | headings | your theme/page (ampy.se: Core Framework) |
| **Outfit** | body | your theme/page |
| **JetBrains Mono** | the numbers | the render **self-injects** it — a local `@font-face` from `wp-content/uploads/fonts/JetBrainsMono-VariableFont_wght.woff2` if present, else the Google Fonts CDN |

So you only need to ensure **Plus Jakarta Sans + Outfit** are available on the page.
On ampy.se they are. Elsewhere, add this to `<head>`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
```

(For best performance, self-host `JetBrainsMono-VariableFont_wght.woff2` at
`/wp-content/uploads/fonts/` so the render uses the local copy instead of the CDN.)

---

## 7. Images (cars & boxes)

The pickers show a **photo** per car/box, falling back to a line icon when no image
is set. There are two layers:

- **In production**, set images in the metabox **"Bilder"** section: each EV and
  laddbox has a *Välj bild / Byt bild / Ta bort* button that opens the standard
  WordPress media library. The chosen image is stored per item and shown on the
  frontend. **This is how Ampy chooses images themselves.**
- **The bundled prototype** ships demo images so you can see the intended look:
  the laddbox photos are Ampy's own product images from `ampy.se`; the **EV photos
  are CC-licensed placeholders from Wikimedia**.
  - ⚠️ **Before go-live, replace the EV images with Ampy's own/licensed photos** via
    the Bilder picker. (Laddbox images are already Ampy's own.)

If no image is set for an item, the original SVG icon is used — nothing breaks.

---

## 8. Place the calculator on a Bricks page

**Option A — Bricks "Code" element (PHP, recommended):** add a Code element, enable
"Execute code", and put:

```php
<?php echo ampy_render_ev_lead_magnet( 'laddboxkalkylator' ); // by slug ?>
```
or by ID: `<?php echo ampy_render_ev_lead_magnet( 56467 ); ?>`
or for the current post: `<?php echo ampy_render_ev_lead_magnet( get_the_ID() ); ?>`

**Option B — Shortcode (any builder / the editor):**
```
[ampy_ev_lead_magnet slug="laddboxkalkylator"]
```
or `[ampy_ev_lead_magnet id="56467"]`.

The render outputs the inline `window.AmpyEvCalcData`, the markup
(`<div class="ampy-calc-outer"><div id="ampyEvCalc">…`), and the JetBrains Mono
`@font-face`. The engine (loaded globally) picks it up and initialises.

Place it in a full-width container; the calculator is responsive down to ~344px and
uses **CSS container queries** (it adapts to *its own* width, not the viewport — so
it behaves correctly even inside a narrow column).

---

## 9. Verify (quick smoke test)

Open the page and confirm:

1. The calculator paints instantly with a default car + box selected and a non-zero
   "Du sparar per år" headline.
2. Changing the car, box, sliders, AC/DC toggle and SE-zone updates the numbers
   live with no console errors.
3. The car/box dropdowns show photos.
4. "Få en laddbox-offert" opens the form; submitting a valid form shows the success
   state and (with a webhook/email configured) delivers the lead. The GDPR consent
   checkbox is required.
5. On a real phone, the sliders drag smoothly and tapping an "i" shows a small tooltip
   (the little circle turns green; no giant box).

Compare against `prototype/` (run it with `python3 -m http.server` — see
`prototype/README.md`). **The WordPress output must look and compute identically.**

The full QA + go-live checklist is in `docs/TESTING-AND-GO-LIVE.md`.

---

## 10. Naming reference (so you know what's safe to touch)

| Thing | Value |
|---|---|
| Function prefix | `ampy_ev_calc_*` (helpers), `ampy_render_ev_lead_magnet()` (render) |
| Post type | `lead-magnet` |
| Post meta | `_ampy_ev_calc_*` (data, excel_id, webhook_url, notify_email, default_car, default_charger, images, leads, import_status, …) |
| REST namespace | `ampy-ev-calc/v1` (`/data/{id}` GET, `/lead/{id}` POST) |
| JS data global | `window.AmpyEvCalcData` |
| JS API global | `window.AmpyEvCalculator` (`.init()`, `.submitLead()`) |
| DOM root | `#ampyEvCalc` (inside `.ampy-calc-outer`) |
| Shortcode | `[ampy_ev_lead_magnet]` |

These names are deliberately namespaced and won't collide with the battery/LED
calculators (which use their own prefixes). Don't rename them — the three layers
reference each other by these exact strings.

---

## 11. Known gaps / decisions still owned by Ampy (not code bugs)

1. **Data sign-off** — the rates and efficiencies are research-backed but must be
   signed off (Swedish marketing law puts the burden of proof on the advertiser).
   See `docs/METHODOLOGY.md`.
2. **Privacy-policy URL** — the consent text links to `/integritetspolicy`
   (placeholder). Point it at the live policy.
3. **EV images** — replace the CC placeholders with licensed/own images (§7).
4. **n8n webhook URL + notify email** — environment-specific (§5).
5. **Support phone** — the error state shows `010-265 79 79`; confirm it's correct.

Everything above is configuration, not code changes.

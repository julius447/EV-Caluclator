# Ampy EV / Laddbox Calculator — implementation package

A complete, self-contained handover of the **EV home-charging savings calculator**
("laddbox-kalkylator") lead magnet, ready to implement into **WordPress + Bricks**.

> **What it does (one line):** the visitor picks their EV and a laddbox, adjusts a
> few inputs (annual km, share of public charging, electricity zone), and instantly
> sees how much they save per year / per month by charging smartly at home instead
> of publicly — then requests a quote. It is a lead-generation tool.

This package contains **all the code**, a **deep technical implementation guide for
an AI coding agent**, and a **human handover** for the developer (Chris).

---

## Read in this order

| # | File | Audience | Purpose |
|---|------|----------|---------|
| 1 | **`HANDOVER.md`** | Chris (human) | The step-by-step implementation walkthrough. **Start here.** |
| 2 | `docs/IMPLEMENTATION-GUIDE.md` | AI agent + dev | Deep technical reference: every file, contract, ID, REST route, data shape, gotcha, and acceptance test. |
| 3 | `docs/ARCHITECTURE.md` | AI agent + dev | The 5-layer model and end-to-end data flow. |
| 4 | `docs/DATA-SCHEMA.md` | Whoever owns the data | The Excel (`.xlsx`) schema and how to edit/regenerate it safely. |
| 5 | `docs/METHODOLOGY.md` | Marketing/legal + dev | The exact calculation, every number it uses, and what still needs Ampy sign-off before go-live. |
| 6 | `docs/TESTING-AND-GO-LIVE.md` | Chris (human) | QA checklist, cross-device tests, and the go-live gate. |

## What's in the box

```
ampy-ev-calculator-handover/
├── README.md                     ← you are here
├── HANDOVER.md                   ← human walkthrough (start here)
├── docs/                         ← the documentation set (see table above)
├── code/
│   ├── fluentsnippets/           ← 3 drop-in snippets (matches Ampy's current setup)
│   │   ├── 1-backend.php          (PHP · run location: "Frontend & Backend" / all)
│   │   ├── 2-engine.js            (JS  · run location: Frontend / wp_footer)
│   │   └── 3-styles.css           (CSS · run location: Frontend / wp_head)
│   └── plugin/                   ← OR the same thing as one installable plugin
│       └── ampy-ev-calculator/    (zip this folder → upload under Plugins)
├── data/
│   └── laddbox-kalkylator-data.xlsx   ← the data file you upload in the metabox
└── prototype/                    ← the exact frontend, runnable with no WordPress
    ├── index.html  data.js  engine.js  styles.css  README.md
```

## Two delivery methods — pick ONE

- **FluentSnippets** (recommended if Ampy already uses it for the battery/LED
  calculators): paste the three files in `code/fluentsnippets/`. The CSS is the
  *same shared stylesheet* the other Ampy calculators use.
- **Plugin**: zip `code/plugin/ampy-ev-calculator/` and upload it. Functionally
  identical; `backend.php` inside it is byte-identical to the FluentSnippets
  backend.

Do not install both at once (you'd register the REST routes/metabox twice).

## The single most important prerequisite

The calculator attaches to a custom post type named **`lead-magnet`**. That CPT is
**not** included in this code (on ampy.se it is registered by the theme / a separate
plugin that the battery + LED calculators also use). **If `lead-magnet` does not
already exist on the target site, register it first** — a ready-to-paste snippet is
in `HANDOVER.md` and `docs/IMPLEMENTATION-GUIDE.md`.

## Status & provenance

- Built and verified against the runnable prototype in `prototype/` (the WordPress
  output is required to match it 1:1).
- Source of truth / version history: the Git repo **github.com/julius447/EV-Caluclator**
  (this package corresponds to `main`). The prototype is also live at
  `https://julius447.github.io/EV-Caluclator/prototype/`.
- Language: the **UI is Swedish** (the product's market); **all documentation here
  is English** per request.

## Before you go live (summary — full list in `docs/TESTING-AND-GO-LIVE.md`)

1. `lead-magnet` CPT exists.
2. Fonts available (Plus Jakarta Sans, Outfit, JetBrains Mono) and the rem scale
   (`html{font-size:62.5%}`) is in effect on the page — see HANDOVER.md §6.
3. The `.xlsx` is uploaded and the importer reports `OK — … imported`.
4. **Data sign-off** on the load-bearing numbers (see `docs/METHODOLOGY.md`).
5. Lead delivery wired (n8n webhook *or* fallback notify email).
6. Privacy-policy URL set (the consent text links to `/integritetspolicy`).
7. Real, licensed product/EV images set via the **Bilder** picker (the bundled EV
   photos are CC placeholders — see HANDOVER.md §7).

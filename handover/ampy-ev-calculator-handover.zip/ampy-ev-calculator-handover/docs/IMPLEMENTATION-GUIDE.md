# Implementation guide (technical reference for an AI coding agent)

This is the precise contract for the Ampy EV / Laddbox Calculator. It is exhaustive
on purpose: an agent should be able to implement, debug, or extend the tool from this
document plus the code in `../code/`. Pair it with `ARCHITECTURE.md` (the flow) and
`../HANDOVER.md` (the human steps).

**Golden rule:** the three frontend layers reference each other by *exact strings*
(element IDs, the data global, CSS class names). Treat the runnable `../prototype/`
as the reference implementation — the WordPress output must be byte-equivalent in
markup, identical in CSS, and reconcile numerically.

---

## 1. File inventory & responsibilities

| File (this package) | Production role | FluentSnippets run location |
|---|---|---|
| `code/fluentsnippets/1-backend.php` | REST API, admin metabox, `.xlsx` importer, image-picker save, render fn, shortcode | PHP · **Frontend & Backend** |
| `code/fluentsnippets/2-engine.js` | `window.AmpyEvCalculator`: calc + render + events + lead submit | JS · **Frontend** (`wp_footer`) |
| `code/fluentsnippets/3-styles.css` | All styling, scoped under `.ampy-calc` / `.ampy-calc-outer` | CSS · **Frontend** (`wp_head`) |
| `code/plugin/ampy-ev-calculator/…` | Same three files as one plugin (`backend.php` unchanged + asset enqueue) | n/a |
| `data/laddbox-kalkylator-data.xlsx` | The data source uploaded in the metabox | n/a |
| `prototype/*` | The WordPress-free reference build | n/a |

The engine and CSS are **byte-identical** between the FluentSnippets and plugin
folders. `backend.php` is identical too; the plugin only adds an enqueue wrapper.

---

## 2. The data contract — `window.AmpyEvCalcData`

`backend.php`'s render function prints this inline `<script>` immediately before the
markup. The engine reads it on init. Full shape:

```jsonc
{
  "EV_MODELS": [
    {
      "id": "tesla-model-y",              // unique slug; the join key for images
      "name": "Tesla Model Y",
      "description": "Vanligast i Sverige", // selector subtitle
      "badge": null,                       // string | null  (e.g. "Populär")
      "available": true,                   // selectable in UI
      "efficiencyKwhPer10km": 1.69,        // kWh per 10 km (WLTP-ish)  ← drives energy
      "onboardAcKw": 11,                   // parsed but NOT used in the calc (informational)
      "imageUrl": "https://…"              // OPTIONAL — added by render from the picker;
    }                                      //            absent ⇒ engine draws the SVG icon
  ],
  "CHARGERS": [
    {
      "id": "zaptec-go",
      "name": "Zaptec Go",
      "description": "Kompakt, upp till 22 kW",
      "badge": "Bästsäljare",              // null | one of the BADGE_TIER keys (see §7)
      "maxPowerKw": 22,                    // parsed but NOT used in the calc
      "priceSek": 4490,                    // NET price (incl. moms, AFTER Grön Teknik) = "Att betala"
      "grossPriceSek": 8980,               // GROSS price (incl. moms, BEFORE Grön Teknik)
      "slug": "https://ampy.se/laddboxar/zaptec-go/", // "Läs mer" link ('#' ⇒ link hidden)
      "available": true,
      "offertOnly": false,                 // true ⇒ no fixed price, CTA shows "Begär offert"
      "imageUrl": "https://…"              // OPTIONAL (picker)
    }
  ],
  "REGIONS": {                             // keyed by SE-zone code; rendered as a segmented control
    "SE3": {
      "label": "SE3 – Södra Mellansverige",
      "homeRateSekPerKwh": 1.60,           // flat all-in home rate kr/kWh (NOTE: not used for the headline; see below)
      "homeRateOptimizedSekPerKwh": 0.90   // SMART (scheduled, low-price-hour) home rate ← the active baseline
    }
  },
  "RATES": {
    "horizonYears": 10,
    "publicAcRateSekPerKwh": 4.50,
    "publicDcRateSekPerKwh": 5.50,
    "chargerEfficiencyPct": 0.90,          // FRACTION (0.90 = 90 %)
    "gronTeknikRate": 0.485,               // FRACTION (informational in methodology; price model uses gross−net)
    "gronTeknikCapPerApplicant": 50000,
    "maxApplicants": 2,
    "uncertaintyBand": 0.10                // FRACTION (±10 %)
  },
  "ADVANCED_DEFAULTS": { "annualKm": 20000, "publicChargingPct": 100, "publicChargingType": "dc" },
  "defaultRegion": "SE3",

  // injected by the WordPress render (absent in the prototype, which hardcodes them):
  "postId": 56467,
  "restUrl": "https://site/wp-json/ampy-ev-calc/v1",
  "nonce": "…"                             // wp_rest nonce for the lead POST
}
```

**Important model note (read `METHODOLOGY.md` for the full rationale):** the headline
saving compares **public charging vs SMART home charging**. In `engine.js`,
`homeRate` is sourced from `homeRateOptimizedSekPerKwh` (the smart rate). The flat
`homeRateSekPerKwh` is still present in the data (and parsed) but is **not** used by
the current calculation. Do not "fix" this — it is an intentional product decision.

Prototype vs WordPress: the prototype's `data.js` hardcodes the whole object (with
`imageUrl`s and `postId:0, restUrl:"", nonce:""`); WordPress builds the same object
from post meta + injects `postId/restUrl/nonce` and merges picker `imageUrl`s.

---

## 3. The calculation (engine.js → `calculateFor(evModelId, chargerId)`)

Pure function of the data + the current `state`
(`{ region, annualKm, publicChargingPct, publicChargingType, numTaxApplicants }`;
`numTaxApplicants` is pinned to 1 — its stepper UI was removed).

```text
annualEnergyNeeded   = (annualKm / 10) * evModel.efficiencyKwhPer10km          // kWh/yr
annualEnergyFromGrid = annualEnergyNeeded / RATES.chargerEfficiencyPct          // +10 % charge loss
publicKwh            = annualEnergyFromGrid * (publicChargingPct / 100)          // kWh currently charged publicly

publicRate = (publicChargingType === "ac") ? RATES.publicAcRateSekPerKwh : RATES.publicDcRateSekPerKwh
homeRate   = REGIONS[region].homeRateOptimizedSekPerKwh        // ← SMART rate is the baseline
rateGap    = publicRate - homeRate

annualSaving       = publicKwh * rateGap                        // the HERO number (kr/yr)
monthlyPublicCost  = publicKwh * publicRate / 12
monthlyHomeCost    = publicKwh * homeRate   / 12                // "Smart laddning" bar
monthlySaving      = monthlyPublicCost - monthlyHomeCost        // reconciles to annualSaving / 12

offert      = charger.offertOnly || charger.priceSek == null
grossPrice  = offert ? null : charger.grossPriceSek
netCost     = offert ? null : charger.priceSek                  // "Att betala"
gronTeknik  = offert ? null : grossPrice - netCost              // NOTE: gross − net, do NOT deduct 48.5 % again
paybackYears = (!offert && annualSaving > 0) ? netCost / annualSaving : null

cumulativeNet[y]     = annualSaving * y - netCost   for y in 0..horizon   // 10-yr "Sparar på 10 år" tile
cumulativeSavings[y] = annualSaving * y                                   // used for offert-only boxes
savingLow/High       = annualSaving * (1 ∓ uncertaintyBand)
```

**Reconciliation invariant** (the QA gate): `monthlySaving * 12 === annualSaving`
(within rounding). Rounding happens only at display time (`fmtKr` etc.), never in the
math.

**Charger price model:** the catalogue ships TWO real prices — `priceSek` (NET, after
Grön Teknik) and `grossPriceSek` (gross). Grön Teknik is just `gross − net`. Never
re-apply the 48.5 % deduction to `priceSek`. Offert-only boxes carry `null` prices →
"Begär offert" and no payback, but the saving still computes (it's price-independent).

---

## 4. Frontend DOM contract (IDs the engine binds to)

The render markup (in `backend.php`, mirrored in `prototype/index.html`) MUST contain
these IDs. The engine fails loudly/partially if any are renamed.

- Root: `#ampyEvCalc` (inside `.ampy-calc-outer` which establishes the
  `container-type: inline-size` query context — **required** for responsiveness).
- Car selector: `#ampyEvCarSelectorA`, `#ampyEvCarButtonA`, `#ampyEvCarListA`,
  `#ampyEvCarNameA`, `#ampyEvCarBestA`, `#ampyEvCarImgA`, `#ampyEvCarBadgeA`,
  label `#ampyEvCarLabel`.
- Charger selector: same with `Charger` instead of `Car`.
- Sliders (built by JS into these containers): `#ampyEvKmContainer` +
  `#ampyEvKmValue` + label `#ampyEvKmLabel`; `#ampyEvPctContainer` +
  `#ampyEvPctValue` + label `#ampyEvPctLabel`.
- Toggle: `#ampyEvPublicType` (buttons `data-value="ac"|"dc"`), label `#ampyEvPubTypeLabel`.
- Region segmented control: `#ampyEvRegion` (built by JS), label `#ampyEvRegionLabel`.
- Results: `#ampyEvAnnualSaving`, `#ampyEvHeroAnnualSub`, `#ampyEvCumulativeValue`,
  `#ampyEvCumulativeLabel`, `#ampyEvHero10Sub`, `#ampyEvNetPay`, `#ampyEvNetPaySub`.
- Monthly panel (TWO bars): `#ampyEvMonthly`, `#ampyEvMonthlyPublic`,
  `#ampyEvMonthlyHome` (the "Smart laddning" bar), `#ampyEvMonthlySaving`. Bar widths
  are driven by CSS custom props `--monthly-public-frac` / `--monthly-home-frac` set
  by JS. (Historical note: a third "flat home" bar `--homeopt` was removed — there is
  no `ampyEvMonthlyHomeOpt` anymore.)
- Breakdown: `#ampyEvSavingsBreakdown`. Methodology: `#ampyEvMethodologyStack`.
- Live region (a11y): `#ampyEvSrStatus` (`role=status aria-live=polite`) — only the
  settled annual-saving headline is announced, debounced ~600 ms.
- CTA + lead form: `#ampyEvCtaQuote`, `#ampyEvLeadForm`, `#ampyEvLeadName`,
  `#ampyEvLeadEmail`, `#ampyEvLeadPhone`, `#ampyEvLeadZip`, the honeypot
  `#ampyEvLeadCompany` (visually hidden), consent `#ampyEvLeadConsent`,
  `#ampyEvLeadSubmit`/`…Label`, `#ampyEvLeadSuccess`, `#ampyEvLeadErrorBox`.
- Product link: `#ampyEvProductLink`, `#ampyEvProductLinkName`.

**Selector behaviour:** custom button + `role="listbox"` (not a native `<select>`),
labelled via `aria-labelledby`, opened by toggling `aria-expanded` on the
`.ampy-calc__selector` wrapper; closes on outside-click / Escape; one open at a time.

**Image rendering:** `setSelectorImg(holder, item)` renders
`<img class="ampy-calc__selector-photo" src=item.imageUrl loading="lazy">` when
`imageUrl` is set, with an `error` listener that swaps back to the SVG icon if the
photo fails to load. Used for both the dropdown option and the selected button.

---

## 5. REST API (`backend.php` → `rest_api_init`)

Namespace `ampy-ev-calc/v1`. `permission_callback` is `__return_true` for both
(public lead magnet); the lead route relies on nonce + honeypot + timing for spam
defence (see §6).

### `GET /data/{post_id}`
Returns the stored `_ampy_ev_calc_data` JSON. 404 if the post isn't a `lead-magnet`
or has no imported data. (The frontend does **not** use this at runtime — the data is
inlined by the render. The route exists for tooling/debugging.)

### `POST /lead/{post_id}`
Header `X-WP-Nonce: <nonce>` (the engine sends the `wp_rest` nonce from the data
object). Body is the lead payload (§"Lead payload"). On receipt the backend:
1. forwards the full JSON to the **n8n webhook** if `_ampy_ev_calc_webhook_url` is set
   (non-blocking `wp_remote_post`), else sends a formatted **fallback email** to
   `_ampy_ev_calc_notify_email`;
2. stores a trimmed record (last 100) in `_ampy_ev_calc_leads`;
3. returns `{ "success": true }`.

The engine's `submitLead(payload)` does the fetch; the prototype overrides it with a
console-logging mock (no backend).

### Lead payload (what the engine POSTs)
```jsonc
{
  "type": "quote_request",
  "timestamp": "ISO-8601",
  "contact": { "name", "email", "phone", "zip",
               "consent": { "given": true, "version": "2026-06-10.1", "text": "…", "timestamp": "ISO" } },
  "inputs":  { "region", "annualKm", "publicChargingPct", "publicChargingType", "numTaxApplicants" },
  "results": { "ev": { "evModelId","evModelName","chargerId","chargerName","offertOnly",
                       "grossPrice","gronTeknik","netCost","annualSaving","paybackYears",
                       "cumulative10","cumulativeSavings10" } },   // null prices for offert-only boxes
  "meta":    { "utmSource","utmMedium","utmCampaign","utmTerm","utmContent","referrer","landingPath","landingUrl" },
  "antibot": { "honeypot","formOpenedAt","submittedAt","elapsedMs" }
}
```
**Server-side spam handling you should keep/verify:** reject if `antibot.honeypot` is
non-empty, or if `elapsedMs` is implausibly small (< ~2 s). Consider per-IP rate
limiting on the route.

---

## 6. GDPR / consent / anti-bot

- A **required, unticked** granular consent checkbox (`#ampyEvLeadConsent`) gates
  submit; the exact wording + a version string (`CONSENT_VERSION`) are sent in the
  payload so the server records *what* was agreed and *when* (GDPR Art. 7). Bump
  `CONSENT_VERSION` in `engine.js` whenever the wording changes.
- A **honeypot** field (`#ampyEvLeadCompany`) — hidden, off the a11y tree, not
  tabbable; a real human leaves it empty.
- **Form-open timestamp** → `antibot.elapsedMs` for sub-2-second bot rejection.
- Third-party analytics fan-out (`window.ampyEvAnalytics`) is **consent-gated**;
  `window.dataLayer` funnel events (`calc_view`, `input_change`, `cta_quote_click`,
  `lead_submit`, `lead_success`) carry no PII.
- The consent text links to `/integritetspolicy` — **replace with the live policy URL.**

---

## 7. Admin: the settings metabox & the image picker

Metabox `EV Charging Calculator — Settings` on the `lead-magnet` edit screen.
Sections: **Lead Delivery** (webhook URL, notify email), **Data Source — Excel File**
(wp.media file picker → `_ampy_ev_calc_excel_id`; on save → parse), **Defaults**
(default car/charger), **Bilder** (per-item image pickers), **Recent Leads** (table).

**Image picker (the "Bilder" section):** lists every imported EV + charger with a
`wp.media` *Välj bild* button (image library). The chosen attachment ID is saved in
`ampy_ev_calc_image[<id>]`; on save the handler resolves each to a URL and stores
`_ampy_ev_calc_images = { "<itemId>": { "id": <attId>, "url": "<url>" } }`. At render,
`ampy_render_ev_lead_magnet()` merges these onto the matching `EV_MODELS`/`CHARGERS`
items as `imageUrl` (purely additive; no entry ⇒ the engine uses the SVG icon).
`backend.php` does **not** put images in the Excel — images are a WP-media concern.

**Badge tiers** (`engine.js` `BADGE_TIER`): `promote` (solid teal — Bästsäljare,
Rekommenderas), `soft` (Prisvärd, Populär, Dubbel laddning, Prisbelönt), `flow`
(muted outline — Offert, Företag/BRF). Unknown tags fall back to `soft`.

---

## 8. Excel importer (`backend.php` → `ampy_ev_calc_parse_excel`)

A dependency-free `.xlsx` reader (ZipArchive + SimpleXML), not PhpSpreadsheet. Sheets:
`EVModels`, `Chargers`, `PriceAreas`, `SystemCoefficients`, `Advanced`. **Row 0 =
headers, row 1 = ignored example row, data from row 2.** Full column reference and the
critical "regenerate with xlsxwriter, NOT openpyxl" warning are in `DATA-SCHEMA.md`.
The importer re-runs only when the attachment ID changes, treats a 0-row import as a
hard error (keeps the previous good data), and reports status in the metabox.

---

## 9. Custom post type (the one external dependency)

`lead-magnet` is **not** registered by this code. Register it (see `../HANDOVER.md`
§2) if it doesn't already exist on the target site. The metabox hooks
`add_meta_boxes` / `save_post_lead-magnet` and the render checks
`post_type === 'lead-magnet'` + `post_status === 'publish'`.

---

## 10. Asset loading & the rem scale

- **FluentSnippets:** CSS at `wp_head`, engine at `wp_footer`, backend "Frontend &
  Backend". The engine's first statement is `if (!window.AmpyEvCalcData) return;` so
  global loading is free on non-calculator pages; CSS is fully scoped.
- **Plugin:** identical effect via `wp_enqueue_style`/`wp_enqueue_script(in_footer)`.
- **Rem scale:** the stylesheet assumes `html{font-size:62.5%}` (1rem = 10px). Ensure
  it on the page (ampy.se already does). The tooltip popover uses px fallbacks so it
  survives a 16px root, but the rest of the UI does not. See `../HANDOVER.md` §6.
- **Fonts:** Plus Jakarta Sans + Outfit must be provided by the page; JetBrains Mono
  is self-injected by the render (local woff2 → Google fallback).

---

## 11. Acceptance criteria (what "correctly implemented" means)

An agent should verify ALL of these:

1. **No console errors** on load or on any input change.
2. **Instant paint**: default car + box selected, headline "Du sparar per år" > 0.
3. **Math reconciles**: `monthlySaving × 12 ≈ annualSaving`; the savings-breakdown
   rows (`publicRate`, smart `homeRate`, `rateGap = public − smart`) are internally
   consistent; the 10-yr tile = `annualSaving × 10 − netCost`.
4. **Defaults** (Tesla Model Y + Zaptec Go + SE3 + DC + 100 % + 20 000 km) reproduce
   the prototype: hero ≈ **17 276 kr/år**, monthly **1 721 / 282 / 1 440**, 10-yr
   **168 266 kr**, Att betala **4 490 kr**. (Cross-check by running `prototype/`.)
5. **Offert-only box** (Zaptec Pro): "Att betala" → "Begär offert", no payback, but
   the saving + monthly panel still render.
6. **Images**: photos show where `imageUrl` is set; items without it show the SVG
   icon (e.g. "Annan elbil"); a broken photo URL falls back to the icon.
7. **Responsive**: correct layout at 1440 px and at 360–390 px; the calculator
   responds to its container width (container queries), not just the viewport.
8. **Touch**: sliders drag smoothly (no scroll-hijack, no lag); tapping an "i" turns
   only the small circle green with the "i" still visible (no large green box).
9. **Lead flow**: validation + required consent; success state on submit; payload
   matches §5; honeypot/timing present.
10. **Prototype parity**: WordPress markup matches `prototype/index.html` (allowing for
    the dynamically injected data/font/nonce), CSS is identical, behaviour matches.

---

## 12. Do-not-break list

- Don't rename any ID / class / global / meta key / REST route in §10/§4/§2.
- Don't change `homeRate` back to the flat rate (the smart-rate baseline is a product
  decision — §3, `METHODOLOGY.md`).
- Don't re-apply the 48.5 % Grön Teknik deduction to `priceSek` (it's already NET).
- Don't regenerate the `.xlsx` with openpyxl (`DATA-SCHEMA.md`).
- Don't remove `html{font-size:62.5%}` from the page context.
- Keep `engine.js` and `styles.css` identical between the prototype and the deployed
  copy (parity is the QA gate).

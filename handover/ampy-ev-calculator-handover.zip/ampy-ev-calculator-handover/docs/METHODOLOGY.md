# Methodology & data sign-off

What the calculator claims, the exact maths behind it, the numbers it ships with, and
**what Ampy must sign off before go-live.** Under Swedish marketing law
(marknadsföringslagen) the burden of proof for a savings claim is on the advertiser,
so this page matters as much as the code.

---

## What it claims

> "How much do you save per year by moving your public charging to **smart** home
> charging?"

The comparison is **public charging vs smart (scheduled, low-price-hour) home
charging**, for the share of energy the user says they currently charge publicly.

---

## The calculation (authoritative)

```
annualEnergyNeeded   = (annualKm / 10) × efficiencyKwhPer10km          [kWh/yr]
annualEnergyFromGrid = annualEnergyNeeded ÷ chargerEfficiency (0.90)    [+10 % charge loss]
publicKwh            = annualEnergyFromGrid × (publicChargingPct / 100)

publicRate  = AC 4.50  or  DC 5.50   [kr/kWh, user chooses]
homeRate    = smart per-zone rate    [kr/kWh — see table]   ← the baseline
rateGap     = publicRate − homeRate

annualSaving       = publicKwh × rateGap                  ← the headline (kr/yr)
monthly: public = publicKwh×publicRate/12, smart = publicKwh×homeRate/12, saving = diff
payback (yr)       = netCost ÷ annualSaving               (only for priced boxes)
10-year ("Sparar på 10 år") = annualSaving × 10 − netCost
uncertainty band   = annualSaving × (1 ± 0.10)
```

Charger price: each box ships a **NET** price (`priceSek`, after Grön Teknik = "Att
betala") and a **GROSS** price (`grossPriceSek`). The deduction shown is simply
`gross − net`. No percentage is re-applied.

---

## Shipped numbers (provisional — require sign-off)

**Electricity rates (kr/kWh)**

| | SE1 | SE2 | SE3 | SE4 |
|---|---|---|---|---|
| Flat home rate (present, **not** used by the headline) | 1.10 | 1.15 | 1.60 | 1.80 |
| **Smart home rate** (the active baseline) | 0.60 | 0.65 | **0.90** | 1.00 |
| Public AC | 4.50 (all zones) |
| Public DC | 5.50 (all zones) |

These are 2025–2026 all-in figures (spot + grid + tax). The smart rate models
charging in the cheapest hours and is set ≈45 % below the flat rate.

**Grön Teknik** (verified vs Skatteverket): 48.5 % effective (the 50 % deduction on
the labour+material with the 97 % schablon ⇒ ≈48.5 % of the total), capped 50 000
kr/applicant/yr, up to 2 applicants. Eligibility: owns the home, has tax to deduct
against, installer has F-skatt, connector per EN 62196-2/-3. Encoded as the
gross/net price pair per box (not recomputed live).

**Other:** charge-loss 10 %, horizon 10 years, uncertainty ±10 %. EV efficiencies are
WLTP-based but provisional.

**Default scenario** (Tesla Model Y, Zaptec Go, SE3, DC, 100 %, 20 000 km):
~17 276 kr/yr; monthly public 1 721 / smart 282 / saving 1 440; 10-yr 168 266 kr;
Att betala 4 490 kr.

---

## ⚠ The headline rests on the SMART (best-case) home rate — read this

Earlier iterations anchored the headline to the **conservative flat** home rate and
showed smart charging as a smaller, additive bonus. Per an explicit owner decision,
the product now leads with **smart charging as the home baseline**, which:

- raises the headline (the public↔home gap is larger against the smart rate), and
- means the lead number assumes the user charges in the cheapest hours (requires a
  spot-priced contract and a box that schedules — a best-case, not worst-case,
  assumption).

This is defensible **if** the methodology copy stays transparent (it does: the UI's
"Så har vi räknat" and the "Smart laddning" tooltip state the ≈45 % low-price-hour
assumption). But because the headline now depends on it, the smart rate is now a
**load-bearing claim** that Ampy must sign off, not a soft upside.

---

## Sign-off checklist (Ampy — before go-live)

- [ ] **Smart home rates** SE1–SE4 (0.60 / 0.65 / 0.90 / 1.00) and the ≈45 %
      low-price-hour reduction — confirmed and substantiable.
- [ ] **Public rates** AC 4.50 / DC 5.50 kr/kWh — confirmed for the target audience.
      (DC maximises the headline; confirm DC vs AC vs a blend is representative.)
- [ ] **Flat home rates** SE1–SE4 — confirmed (shown in copy/range even if not the
      headline baseline).
- [ ] **EV efficiencies** (`efficiency_kwh_per_10km`) — verified per model.
- [ ] **Charger gross/net prices + product URLs** — match the live ampy.se catalogue.
- [ ] **Grön Teknik** parameters (48.5 %, 50 000 kr, 2 applicants, eligibility) —
      current for the launch tax year.
- [ ] The disclaimer + "Så har vi räknat" wording — approved by marketing/legal.

A fuller research dossier (sources for each figure, the Grön Teknik verification, the
scheduled-charging analysis, the catalogue audit) exists in the source repo under
`research/` (`DATA-DOSSIER.md`, `gron-teknik-verified.md`, `r3-scheduled-charging.md`,
`CATALOGUE.md`). Use it as the substantiation file for the sign-off.

> Update path: change the numbers in the Excel (`DATA-SCHEMA.md`), re-upload, done —
> no code change. If the smart-rate reduction % changes, also update the tooltip /
> methodology copy strings in `engine.js` so the claim and the copy stay aligned.

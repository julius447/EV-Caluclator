# Testing & go-live checklist

Run these after implementing. Compare everything against the runnable `../prototype/`
(see `../prototype/README.md`) — the WordPress output must match it.

## A. Install / config sanity

- [ ] `lead-magnet` CPT exists (menu visible).
- [ ] Code installed via ONE method (FluentSnippets *or* plugin, not both).
- [ ] `.xlsx` uploaded; metabox shows green **`OK — 8 EV models, 16 chargers
      imported.`** (not a red error, not `0 imported`).
- [ ] Calculator placed on a page (Code element or shortcode) and renders.
- [ ] Page root is `font-size: 62.5%` (1rem = 10px); Plus Jakarta Sans + Outfit load;
      numbers render in JetBrains Mono.

## B. Functional (desktop)

- [ ] Instant paint: default car + box, headline **Du sparar per år ≈ 17 276 kr/år**
      (Tesla Model Y + Zaptec Go + SE3 + DC + 100 % + 20 000 km).
- [ ] Monthly panel shows **two** bars: Offentlig laddning **1 721** / Smart laddning
      **282**, "Du sparar **1 440** kr/mån". 10-yr tile **168 266 kr**. Att betala
      **4 490 kr**.
- [ ] Changing car / box / km slider / % slider / AC↔DC / SE1–SE4 updates all numbers
      live, with **no console errors**.
- [ ] Math reconciles: monthly saving × 12 ≈ annual; breakdown rows
      (public rate, smart rate, gap) consistent.
- [ ] Offert-only box (Zaptec Pro): "Att betala" → **Begär offert**, no payback, but
      the saving + monthly panel still show.
- [ ] "Läs mer om {box}" links to the box's product URL (hidden if URL is `#`).

## C. Images

- [ ] Car & box dropdowns show **photos**; the selected items show photos.
- [ ] An item without an image (e.g. "Annan elbil") shows the **SVG icon** (no broken
      image).
- [ ] Setting an image in the metabox **Bilder** picker updates the frontend after
      save.

## D. Lead flow

- [ ] "Få en laddbox-offert" opens the form and focuses the name field.
- [ ] Validation: name ≥ 2, valid email, phone, 5-digit postcode; the **consent
      checkbox is required** (submit blocked + inline error when unticked).
- [ ] Valid submit → success state; with a webhook/email configured the lead arrives;
      it appears in the metabox **Recent Leads** table.
- [ ] Payload contains `contact.consent` (version + text + timestamp), `inputs`,
      `results.ev`, `meta` (UTM), `antibot` (honeypot empty, elapsedMs).

## E. Mobile / touch (test on a REAL iPhone + a REAL Android — see note)

- [ ] Layout is clean at 360–390 px; nothing overflows; slider ticks legible.
- [ ] **Sliders drag smoothly** with a finger — the thumb tracks 1:1, the page does
      not scroll-hijack mid-drag, and the value snaps on release.
- [ ] Tapping an **"i"** shows a small tooltip; **only the little circle turns green
      with the "i" still visible** — no big green box, no layout jump.
- [ ] Tooltip closes on outside-tap / scroll; one open at a time.

> Why a real device: a desktop browser (even in responsive mode) reports a *fine*
> pointer, so the touch-only CSS path (`@media (pointer: coarse)`) and real touch
> drag behaviour cannot be fully exercised by resizing a desktop window.

## F. Accessibility

- [ ] Keyboard: Tab reaches the selectors, sliders (arrow keys change value), toggle,
      region, form fields, CTA.
- [ ] Selectors expose name via `aria-labelledby`; sliders expose
      `aria-valuenow`/`aria-valuetext`.
- [ ] The polite live region announces only the settled annual-saving headline (not a
      flood on every keystroke).
- [ ] `prefers-reduced-motion` is respected (animations collapse).
- [ ] Colour contrast on the dark results card and the teal CTA meets AA.

## G. Parity

- [ ] WordPress markup matches `prototype/index.html` (allowing for the injected
      data/font/nonce). `engine.js` and `styles.css` are byte-identical to the
      prototype's. Behaviour and numbers match.

## H. Go-live gate (Ampy decisions — see `METHODOLOGY.md`)

- [ ] **Data sign-off** complete (smart + public + flat rates, EV efficiencies,
      Grön Teknik params).
- [ ] Real charger gross/net prices + product URLs confirmed against ampy.se.
- [ ] **EV images replaced** with Ampy's own/licensed photos (the bundled EV photos
      are CC placeholders).
- [ ] **Privacy-policy URL** set (consent text links to `/integritetspolicy`).
- [ ] **n8n webhook URL** (or fallback notify email) configured and a test lead
      received end-to-end.
- [ ] Support phone in the error state (`010-265 79 79`) confirmed.
- [ ] Disclaimer / "Så har vi räknat" copy approved by marketing/legal.

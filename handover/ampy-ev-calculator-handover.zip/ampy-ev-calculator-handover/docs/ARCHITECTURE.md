# Architecture

A small, dependency-free, three-layer calculator. No build step, no framework, no
runtime data fetch on the frontend.

## The three layers

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ DATA            Excel (.xlsx)                                                  │
│                  │  uploaded in the lead-magnet metabox                        │
│                  ▼                                                             │
│                 backend.php : ampy_ev_calc_parse_excel()                       │
│                  │  parses 5 sheets → JSON                                     │
│                  ▼                                                             │
│                 post meta  _ampy_ev_calc_data   (+ _ampy_ev_calc_images)       │
└─────────────────────────────────────────────────────────────────────────────┘
                   │  ampy_render_ev_lead_magnet($idOrSlug)
                   ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ VIEW + LOGIC    backend.php prints, into the page:                            │
│                   <script>window.AmpyEvCalcData = { … }</script>   (inline)    │
│                   <div class="ampy-calc-outer"><div id="ampyEvCalc">…</div>    │
│                   <style>@font-face JetBrains Mono…</style>                     │
│                  │                                                             │
│                  ▼                                                             │
│                 engine.js  (IIFE → window.AmpyEvCalculator)                     │
│                   • reads window.AmpyEvCalcData                                 │
│                   • renders selectors / sliders / region / results into #ampyEvCalc
│                   • calculateFor() on every input (pure function)              │
│                   • POSTs the lead → REST → n8n webhook / fallback email       │
└─────────────────────────────────────────────────────────────────────────────┘
                   ▲
┌─────────────────────────────────────────────────────────────────────────────┐
│ STYLE           styles.css   (scoped under .ampy-calc / .ampy-calc-outer)      │
│                   • design tokens as CSS custom props on .ampy-calc            │
│                   • @container ampy queries → responds to its OWN width        │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Key design decisions (and why)

- **Data is inlined, not fetched.** The render prints `window.AmpyEvCalcData` into the
  page, so the calculator paints instantly with no network round-trip and no loading
  state. The REST `/data` route exists only for tooling.
- **Excel as the data source.** Non-technical staff edit a spreadsheet and re-upload;
  the importer turns it into the JSON contract. No code change to update cars/boxes/rates.
- **Container queries, not media queries.** All breakpoints reference the
  `.ampy-calc-outer` container (`container-type: inline-size`), so the calculator
  lays out correctly whether it's full-width or inside a narrow Bricks column.
- **Scoped everything.** CSS lives under `.ampy-calc*`; JS namespaces every global,
  ID, meta key and REST route with `ampy(_ev)…`. It coexists with Ampy's battery and
  LED calculators (which share the same stylesheet but use their own JS/PHP prefixes).
- **Graceful degradation.** The engine self-exits on pages without the data global;
  photos fall back to SVG icons; offert-only boxes fall back to "Begär offert"; a
  0-row import keeps the previous good data.
- **Prototype = reference.** `prototype/` is the exact frontend bundle wired to local
  placeholder data with a mocked lead submit. It is the spec the WordPress output must
  match. Keep `engine.js` / `styles.css` identical between the two.

## Request lifecycle (a visitor session)

1. Page with the Bricks Code element / shortcode renders → inline data + markup +
   font; `engine.js` (footer) runs `init()` on DOMContentLoaded.
2. `init()` picks defaults, builds the selectors/sliders/region, wires events, runs
   the first `renderAll()`, emits `calc_view`.
3. Each input change → `renderAll()` → `calculateFor()` → DOM update + debounced SR
   announce + `input_change` event.
4. "Få en laddbox-offert" → form opens (`cta_quote_click`) → validate + consent →
   `buildPayload()` → `submitLead()` → `POST /lead` → webhook/email → success state
   (`lead_submit` → `lead_success`).

See `IMPLEMENTATION-GUIDE.md` for the exact contracts at each step.

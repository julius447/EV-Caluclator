# Excel data schema — `laddbox-kalkylator-data.xlsx`

The data file you upload in the lead-magnet metabox. The PHP importer
(`ampy_ev_calc_parse_excel` + five `ampy_ev_calc_parse_*` sheet parsers in
`backend.php`) reads it and stores the resulting JSON in post meta
`_ampy_ev_calc_data`, which becomes `window.AmpyEvCalcData` on the frontend.

> This file reflects the **current** data (8 EV models, 16 chargers, gross + net
> pricing, per-zone smart rates). The numbers themselves still need Ampy sign-off
> before go-live — see `METHODOLOGY.md`.

---

## Row layout (EVERY sheet)

The importer reads **row 0** (first spreadsheet row) as the column headers, then
loops `for ($i = 2; …)` — i.e. **data starts at row index 2 (the third row)**. Row
index 1 (second row) is an **example row that is ignored** (its first cell reads
`EXEMPEL – ignoreras vid import`).

| Spreadsheet row | Role | Importer |
|---|---|---|
| Row 1 | Header strings (exact column names) | read as the header map |
| Row 2 | Example/hint row | **ignored** |
| Row 3+ | Real data | parsed |

Do not delete/reorder rows 1–2. Append real data from row 3. Columns are mapped by
header name, not position, but keep the given order for readability.

**Conventions**
- Booleans (`active`, `offert`, `is_default`): the literal lowercase text `true` /
  `false` (stored as text, not spreadsheet booleans). Parser does
  `strtolower(...) === 'true'`.
- Empty `badge` cell ⇒ `null`.
- `sort_order` = `1..n` ascending display order (blank ⇒ 999).
- "pct" coefficients are stored as **fractions** (0.90 = 90 %), NOT 0–100.

---

## Sheet 1 — `EVModels`  (8 rows)

`model_id | name | description | badge | active | efficiency_kwh_per_10km | onboard_ac_kw | sort_order`

| Column | Type | Meaning | JSON key |
|---|---|---|---|
| `model_id` | text | unique slug; blank ⇒ row skipped; the join key for images | `id` |
| `name` | text | display name (**real**) | `name` |
| `description` | text | selector subtitle | `description` |
| `badge` | text/empty | optional label | `badge` |
| `active` | true/false | selectable | `available` |
| `efficiency_kwh_per_10km` | number | kWh per 10 km — **drives the energy calc**; default 1.70 ⚠ verify | `efficiencyKwhPer10km` |
| `onboard_ac_kw` | number | on-board AC power; parsed but **not used in the calc** | `onboardAcKw` |
| `sort_order` | int | display order | (sort only) |

EV **names are real**; the **efficiency figures need verification** (WLTP-based but
treat as provisional).

## Sheet 2 — `Chargers`  (16 rows)

`charger_id | name | description | badge | max_power_kw | price_sek | gross_price_sek | offert | learn_more_url | active | sort_order`

| Column | Type | Meaning | JSON key |
|---|---|---|---|
| `charger_id` | text | unique slug; blank ⇒ skipped | `id` |
| `name` | text | display name | `name` |
| `description` | text | selector subtitle | `description` |
| `badge` | text/empty | Bästsäljare / Rekommenderas / Prisvärd / Populär / Dubbel laddning / Prisbelönt / Offert / Företag/BRF | `badge` |
| `max_power_kw` | number | max charge power; parsed but **not used in the calc** | `maxPowerKw` |
| `price_sek` | number | **NET** price incl. moms, **after Grön Teknik** = "Att betala"; blank+`offert=false` ⇒ row skipped | `priceSek` |
| `gross_price_sek` | number | **GROSS** price incl. moms, **before** Grön Teknik | `grossPriceSek` |
| `offert` | true/false | `true` ⇒ offert-only (leave price cells blank) → "Begär offert" | `offertOnly` |
| `learn_more_url` | text | product page URL (`#` ⇒ "Läs mer" link hidden) | `slug` |
| `active` | true/false | selectable | `available` |
| `sort_order` | int | display order | (sort only) |

**Pricing model:** the calculator shows `price_sek` as "Att betala" and computes
Grön Teknik as `gross_price_sek − price_sek`. So fill **both** real prices; do not
pre-deduct anything else. For offert-only boxes (Zaptec Pro), leave `price_sek` and
`gross_price_sek` blank and set `offert = true`. (Garo Entity Pro currently ships a
real 7350/14700 price; flip to offert-only by blanking the prices + `offert=true` if
Ampy prefers.)

Laddbox **names/prices/URLs are Ampy's own catalogue values** — confirm against the
live product pages at go-live.

## Sheet 3 — `PriceAreas`  (4 rows)

`area_code | name | home_rate_sek_per_kwh | home_rate_optimized_sek_per_kwh | is_default`

| Column | Type | Meaning | JSON key |
|---|---|---|---|
| `area_code` | text | `SE1`..`SE4`; becomes the REGIONS key | (key) |
| `name` | text | display label | `label` |
| `home_rate_sek_per_kwh` | number | flat all-in home rate kr/kWh (**present but NOT used by the current headline calc**) | `homeRateSekPerKwh` |
| `home_rate_optimized_sek_per_kwh` | number | **SMART** (scheduled/low-price-hour) home rate — **this is the active baseline** the saving compares against | `homeRateOptimizedSekPerKwh` |
| `is_default` | true/false | exactly one row `true` (SE3) | sets `defaultRegion` |

Blank `home_rate_optimized_sek_per_kwh` ⇒ parser falls back to ~78 % of the flat
rate. The product currently leads with the **smart** rate; see `METHODOLOGY.md` for
why and what needs sign-off.

## Sheet 4 — `SystemCoefficients`  (key | value)

| key | current | Meaning | JSON key |
|---|---|---|---|
| `horizon_years` | 10 | projection horizon (int) | `horizonYears` |
| `public_ac_rate_sek_per_kwh` | 4.50 | public AC rate kr/kWh | `publicAcRateSekPerKwh` |
| `public_dc_rate_sek_per_kwh` | 5.50 | public DC (fast) rate kr/kWh | `publicDcRateSekPerKwh` |
| `charger_efficiency_pct` | 0.90 | charge efficiency **fraction** | `chargerEfficiencyPct` |
| `gron_teknik_pct` | 0.485 | Grön Teknik **fraction** (used in methodology copy; price model uses gross−net) | `gronTeknikRate` |
| `gron_teknik_cap_per_applicant_sek` | 50000 | cap per applicant (int) | `gronTeknikCapPerApplicant` |
| `max_applicants` | 2 | max applicants (int) | `maxApplicants` |
| `uncertainty_pct` | 0.10 | ±band **fraction** | `uncertaintyBand` |

## Sheet 5 — `Advanced`  (key | default — the UI control defaults)

| key | current | Meaning | JSON key |
|---|---|---|---|
| `annual_km` | 20000 | default annual km | `annualKm` |
| `public_charging_pct` | 100 | default public-charging share (**0–100**, the slider value) | `publicChargingPct` |
| `public_charging_type` | dc | default public type `ac`/`dc` | `publicChargingType` |

---

## Regenerating the file

Use a writer that emits a **shared-string table + RELATIVE worksheet relationships**:
Excel, LibreOffice, Google Sheets (export `.xlsx`), or Python **`xlsxwriter`**. The
generator that produced this file is `build_xlsx.py` in the source repo; verify with
`verify_faithful.py` (a faithful Python port of the PHP parser) — it must print
`PASS — deep-equal`.

### ⚠️ Do NOT regenerate with openpyxl
The current PHP parser has two quirks openpyxl's output trips, producing a **silent**
`OK — 0 imported` (empty calculator):
1. `build_sheet_map()` resolves sheet paths only for **relative** rels targets
   (`worksheets/sheet1.xml`); openpyxl writes **absolute** (`/xl/...`) → path doubles
   → 0 rows.
2. `read_sheet()` handles shared-string and boolean cells but not openpyxl's
   `inlineStr` text → text cells read empty → rows skipped.

xlsxwriter / Excel / LibreOffice avoid both. (A future parser hardening — normalise
absolute targets + handle `inlineStr` — would remove this constraint; until then,
use a compatible writer.)

After editing, **re-upload** the file in the metabox and pick it (the importer only
re-parses when the attachment ID changes). Images are NOT in the spreadsheet — they
are set via the metabox "Bilder" picker.

<?php
/**
 * Plugin Name:       Ampy EV / Laddbox Calculator
 * Plugin URI:        https://ampy.se/
 * Description:        EV home-charging savings calculator (laddbox-kalkylator) lead magnet. Provides the REST API, the admin settings metabox, the Excel (.xlsx) data importer, a per-item WP-media image picker, the render function ampy_render_ev_lead_magnet() and the [ampy_ev_lead_magnet] shortcode. The frontend engine + styles are enqueued site-wide; the engine self-exits on any page without the calculator, and all CSS is scoped under .ampy-calc / .ampy-calc-outer, so global loading is safe.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Ampy
 * License:           GPL-2.0-or-later
 * Text Domain:       ampy-ev-calc
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * This is an OPTIONAL packaging of the calculator as a single, self-contained
 * plugin. It is functionally identical to the three FluentSnippets snippets in
 * ../../fluentsnippets/ — pick ONE delivery method, not both:
 *
 *   • FluentSnippets : paste 1-backend.php / 2-engine.js / 3-styles.css as three
 *                       snippets (matches Ampy's current setup). See HANDOVER.md.
 *   • This plugin    : zip the `ampy-ev-calculator/` folder and upload it under
 *                       Plugins → Add New → Upload, then Activate.
 *
 * `backend.php` here is byte-identical to the FluentSnippets backend snippet and
 * is intentionally left UNCHANGED. The only plugin-specific code is the asset
 * enqueue below. See docs/IMPLEMENTATION-GUIDE.md for the full architecture.
 * ─────────────────────────────────────────────────────────────────────────────
 */

defined( 'ABSPATH' ) || exit;

define( 'AMPY_EV_CALC_VER', '1.0.0' );
define( 'AMPY_EV_CALC_DIR', plugin_dir_path( __FILE__ ) );
define( 'AMPY_EV_CALC_URL', plugin_dir_url( __FILE__ ) );

/*
 * Backend: REST routes (ampy-ev-calc/v1), the `lead-magnet` settings metabox,
 * the .xlsx importer, the image picker save, the render function and shortcode.
 * IDENTICAL to the FluentSnippets "Backend" snippet.
 *
 * NOTE: this plugin does NOT register the `lead-magnet` custom post type — see
 * HANDOVER.md §"Prerequisite: the lead-magnet post type". Register it in your
 * theme/CPT plugin (a ready snippet is provided), or the metabox/render will not
 * appear.
 */
require_once AMPY_EV_CALC_DIR . 'backend.php';

/*
 * Frontend assets, loaded site-wide:
 *   • styles.css → <head>   (scoped under .ampy-calc / .ampy-calc-outer)
 *   • engine.js  → footer   (in_footer=true; runs AFTER the inline
 *                            window.AmpyEvCalcData that the render prints in the
 *                            page body, so the data is always available)
 *
 * The engine's first line is `if ( !window.AmpyEvCalcData ) return;`, so on pages
 * without the calculator it costs one property read and exits. This mirrors the
 * FluentSnippets run locations (CSS = wp_head, JS = wp_footer).
 *
 * If you prefer to load assets ONLY on pages that contain the calculator, replace
 * the global enqueue with an enqueue call inside ampy_render_ev_lead_magnet().
 */
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style(
		'ampy-ev-calc',
		AMPY_EV_CALC_URL . 'assets/styles.css',
		array(),
		AMPY_EV_CALC_VER
	);
	wp_enqueue_script(
		'ampy-ev-calc',
		AMPY_EV_CALC_URL . 'assets/engine.js',
		array(),
		AMPY_EV_CALC_VER,
		true
	);
} );

/*
 * The WP media picker in the settings metabox needs the media modal scripts on
 * the lead-magnet edit screen. (FluentSnippets loads these because the classic
 * editor enqueues them; in a plugin context we make it explicit and harmless.)
 */
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		wp_enqueue_media();
	}
} );

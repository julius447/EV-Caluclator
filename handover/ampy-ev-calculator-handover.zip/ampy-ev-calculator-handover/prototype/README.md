# Prototype — the runnable reference frontend

A WordPress-free copy of the exact frontend bundle: the **same `engine.js` and
`styles.css` that ship in production**, wired to a local `data.js` instead of
WordPress post meta, with a mocked lead submit. Use it as the visual + behavioural
**reference**: the WordPress output must match this.

## Run it

Any static server works (the calculator is vanilla JS, no build step). From this
`prototype/` folder:

```bash
python3 -m http.server 8000
# then open http://localhost:8000
```

(Opening `index.html` via `file://` mostly works too, but a server is recommended so
fonts and relative paths behave.)

## Files

| File | What it is |
|---|---|
| `index.html` | Page shell + the calculator markup (the same markup the PHP render emits). Sets `html{font-size:62.5%}` and loads the three Google fonts. |
| `styles.css` | **Byte-identical** to the production stylesheet. |
| `engine.js`  | **Byte-identical** to the production JS engine (auto-inits on load). |
| `data.js`    | Sets `window.AmpyEvCalcData` with the dataset, including `imageUrl`s. |

Load order (in `index.html`): `data.js` in `<head>` (before the engine) → markup →
`engine.js` at the end of `<body>`.

## What is placeholder / demo data here

- **EV efficiencies** and the **electricity rates** are provisional pending Ampy
  sign-off (see `../docs/METHODOLOGY.md`).
- **Laddbox photos** are Ampy's own product images from ampy.se. **EV photos are
  CC-licensed placeholders** (Wikimedia) — in production these are set via the WP
  media picker; replace before go-live.
- **Lead submit is mocked.** An inline script at the bottom of `index.html` overrides
  `window.AmpyEvCalculator.submitLead` to log the payload to the console and resolve
  success — so the form shows its success state but nothing is sent. Open the browser
  console to inspect the exact payload that production would POST to the REST API.

## Default scenario (for cross-checking the WordPress build)

Tesla Model Y + Zaptec Go + SE3 + DC + 100 % + 20 000 km →
**Du sparar per år ≈ 17 276 kr** · monthly public **1 721** / smart **282** / saving
**1 440** · 10-yr **168 266 kr** · Att betala **4 490 kr**.
